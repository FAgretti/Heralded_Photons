.. _api-dev-toc:

===========================
SciPy API Development Guide
===========================

.. toctree::
   :maxdepth: 1

   nan_policy
   special_ufuncs
   array_api
