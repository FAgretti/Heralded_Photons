:orphan:

.. raw:: html

   <div class="prename">{{ module }}.{{ class }}.</div>
   <div class="empty"></div>

{{ fullname }}
{{ underline }}

.. currentmodule:: {{ module }}

.. autoproperty:: {{ objname }}
