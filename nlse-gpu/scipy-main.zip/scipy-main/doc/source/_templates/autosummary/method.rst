:orphan:

.. raw:: html

   <div class="prename">{{ module }}.{{ class }}.</div>
   <div class="empty"></div>

{{ name }}
{{ underline }}

.. currentmodule:: {{ module }}

.. automethod:: {{ objname }}
