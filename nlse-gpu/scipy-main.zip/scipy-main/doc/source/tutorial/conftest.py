from scipy.conftest import dt_config    # noqa: F401
