:orphan:

.. automodule:: scipy.io.matlab
   :no-members:
   :no-inherited-members:
   :no-special-members:
