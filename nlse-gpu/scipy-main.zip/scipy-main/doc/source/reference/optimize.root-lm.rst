.. _optimize.root-lm:

root(method='lm')
--------------------------------

.. scipy-optimize:function:: scipy.optimize.root
   :impl: scipy.optimize._root._root_leastsq
   :method: lm
