.. automodule:: scipy.linalg.interpolative
   :no-members:
   :no-inherited-members:
   :no-special-members:
