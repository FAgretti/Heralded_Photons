.. automodule:: scipy.stats.contingency
   :no-members:
   :no-inherited-members:
   :no-special-members:
