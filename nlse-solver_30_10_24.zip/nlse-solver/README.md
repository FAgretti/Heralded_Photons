# NLSE-solver

Repositorio de código para simulaciones con la _ecuación de schrödinger no lineal_
