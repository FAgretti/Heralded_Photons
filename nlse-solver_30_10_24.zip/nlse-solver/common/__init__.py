# -*- coding: utf-8 -*-
"""
Created on Thu Jul 11 17:30:17 2024

@author: gutie
"""

